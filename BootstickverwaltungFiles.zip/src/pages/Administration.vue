<template>
  <!-- Der Template-Teil bleibt unverändert -->
  <div class="container">
    <h1 class="page-title">Administration</h1>

    <!-- Stick hinzufügen -->
    <section>
      <h3>Stick hinzufügen</h3>
      <div class="form-group">
        <label for="stickType">USB-Stick Typ</label>
        <select id="stickType" v-model="newStick.type" class="form-control" required>
          <option value="" disabled>Bitte wählen...</option>
          <option v-for="type in stickTypes" :key="type" :value="type">{{ type }}</option>
        </select>
      </div>
      <div class="form-group">
        <label for="condition">Zustand</label>
        <select id="condition" v-model="newStick.condition" class="form-control" required>
          <option value="" disabled>Bitte wählen...</option>
          <option v-for="condition in conditions" :key="condition" :value="condition">{{ condition }}</option>
        </select>
      </div>
      <div class="form-group">
        <label for="storageCapacity">Speicherkapazität</label>
        <input
          id="storageCapacity"
          type="text"
          class="form-control"
          v-model="newStick.storageCapacity"
          placeholder="Speicherkapazität eingeben"
        />
      </div>
      <div class="form-group">
        <label for="serialNumber">Seriennummer</label>
        <input
          id="serialNumber"
          type="text"
          class="form-control"
          v-model="newStick.serialNumber"
          placeholder="Seriennummer eingeben"
        />
      </div>
      <div class="form-group">
        <label for="inventoryNumber">Inventarnummer</label>
        <input
          id="inventoryNumber"
          type="text"
          class="form-control"
          v-model="newStick.inventoryNumber"
          placeholder="Inventarnummer eingeben"
        />
      </div>
      <div class="form-group">
        <label for="manufacturerModel">Hersteller und Modell</label>
        <input
          id="manufacturerModel"
          type="text"
          class="form-control"
          v-model="newStick.manufacturerModel"
          placeholder="Hersteller und Modell eingeben"
        />
      </div>
      <button class="button" @click="addStick">Stick hinzufügen</button>
    </section>

    <!-- Stick-Gruppen verwalten -->
    <section>
      <h3>Stick-Gruppen verwalten</h3>
      <div class="form-group">
        <label for="newGroup">Neue Gruppe erstellen</label>
        <input
          id="newGroup"
          type="text"
          class="form-control"
          v-model="newGroup"
          placeholder="Neue Gruppe eingeben"
        />
      </div>
      <button class="button" @click="addGroup">Gruppe erstellen</button>
    </section>

    <!-- Bestehende Gruppen -->
    <section>
      <h3>Bestehende Gruppen</h3>
      <div class="table-container">
        <table class="table">
          <thead>
            <tr>
              <th>Gruppen</th>
              <th>Anzahl der Sticks</th>
              <th>Aktionen</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="group in stickGroups" :key="group.groupId">
              <td>{{ group.groupId }}</td>
              <td>{{ group.numberOfSticks }}</td>
              <td>
                <button class="button" style="background-color: yellow; color: black;" @click="openEditGroupPopup(group)">Bearbeiten</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </section>

    <!-- Vorhandene Sticks verwalten -->
    <section>
      <h3>Vorhandene Sticks verwalten</h3>
      <div class="table-container">
        <table class="table">
          <thead>
            <tr>
              <th>Inventarnummer</th>
              <th>Typ</th>
              <th>Zustand</th>
              <th>Speicherkapazität</th>
              <th>Hersteller und Modell</th>
              <th>Seriennummer</th>
              <th>Aktionen</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="stick in allSticks" :key="stick.inventoryNumber">
              <td>{{ stick.inventoryNumber }}</td>
              <td>{{ stick.type }}</td>
              <td>{{ stick.condition }}</td>
              <td>{{ stick.storageCapacity }}</td>
              <td>{{ stick.manufacturer }} {{ stick.model }}</td>
              <td>{{ stick.serialNumber }}</td>
              <td>
                <button class="button" style="background-color: yellow; color: black;" @click="openEditStickPopup(stick)">Bearbeiten</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </section>

    <!-- Popup für Gruppenbearbeitung -->
    <div v-if="isEditGroupPopupOpen" class="popup-overlay">
      <div class="popup-content">
        <span class="close-popup" @click="closeEditGroupPopup">&times;</span>
        <h3>Sticks in Gruppe {{ selectedGroup.groupId }}</h3>
        <ul>
          <li v-for="stick in selectedGroup.sticks" :key="stick.inventoryNumber">
            {{ stick.inventoryNumber }} - {{ stick.type }} ({{ stick.condition }})
            <button @click="removeStickFromGroup(stick.inventoryNumber)">Entfernen</button>
          </li>
        </ul>
        <div>
          <h4>Stick hinzufügen</h4>
          <select v-model="newStickToAdd" class="form-control">
            <option value="" disabled>Bitte wählen...</option>
            <option v-for="stick in availableSticks" :key="stick.inventoryNumber" :value="stick.inventoryNumber">
              {{ stick.inventoryNumber }} - {{ stick.type }}
            </option>
          </select>
          <button class="button" @click="addStickToGroup">Hinzufügen</button>
        </div>
        <button class="button" style="background-color: red; color: white;" @click="deleteGroup(selectedGroup.groupId)">Gruppe löschen</button>
      </div>
    </div>

    <!-- Popup für Stickbearbeitung -->
    <div v-if="isEditStickPopupOpen" class="popup-overlay">
      <div class="popup-content">
        <span class="close-popup" @click="closeEditStickPopup">&times;</span>
        <h3>Stick bearbeiten</h3>
        <div class="form-group">
          <label for="editType">Typ</label>
          <select id="editType" v-model="selectedStick.type" class="form-control" required>
            <option v-for="type in stickTypes" :key="type" :value="type">{{ type }}</option>
          </select>
        </div>
        <div class="form-group">
          <label for="editCondition">Zustand</label>
          <select id="editCondition" v-model="selectedStick.condition" class="form-control" required>
            <option v-for="condition in conditions" :key="condition" :value="condition">{{ condition }}</option>
          </select>
        </div>
        <div class="form-group">
          <label for="editStorageCapacity">Speicherkapazität</label>
          <input
            id="editStorageCapacity"
            type="text"
            class="form-control"
            v-model="selectedStick.storageCapacity"
          />
        </div>
        <div class="form-group">
          <label for="editSerialNumber">Seriennummer</label>
          <input
            id="editSerialNumber"
            type="text"
            class="form-control"
            v-model="selectedStick.serialNumber"
          />
        </div>
        <div class="form-group">
          <label for="editManufacturerModel">Hersteller und Modell</label>
          <input
            id="editManufacturerModel"
            type="text"
            class="form-control"
            v-model="selectedStick.manufacturerModel"
          />
        </div>
        <button class="button" @click="updateStick">Speichern</button>
        <button class="button" style="background-color: red; color: white;" @click="deleteStick(selectedStick.inventoryNumber)">Stick löschen</button>
      </div>
    </div>
  </div>
</template>

<script>
import axios from "axios";

export default {
  name: "AdministrationPage",
  data() {
    return {
      stickGroups: [],
      allSticks: [],
      stickTypes: [],
      conditions: ["Neu", "Gebraucht", "Defekt"],
      newStick: {
        type: "",
        condition: "",
        storageCapacity: "",
        serialNumber: "",
        inventoryNumber: "",
        manufacturerModel: "",
      },
      newGroup: "",
      isEditGroupPopupOpen: false,
      isEditStickPopupOpen: false,
      selectedGroup: null,
      selectedStick: null,
      newStickToAdd: "",
    };
  },
  computed: {
    availableSticks() {
      const sticksInGroups = this.stickGroups.flatMap((group) => group.sticks);
      return this.allSticks.filter(
        (stick) =>
          !sticksInGroups.some((s) => s.inventoryNumber === stick.inventoryNumber) &&
          stick.type === this.selectedGroup.stickType // Nur Sticks mit demselben Typ
      );
    },
  },
  methods: {
    async loadData() {
      try {
        const response = await axios.get("http://localhost:3000/api/data");
        const data = response.data;
        this.stickGroups = data.stickGroups;
        this.allSticks = data.stickGroups.flatMap((group) => group.sticks);
        this.stickTypes = Array.from(new Set(data.stickGroups.map((group) => group.stickType)));
      } catch (error) {
        console.error("Fehler beim Laden der Daten:", error);
      }
    },
    async saveData() {
      const data = {
        stickGroups: this.stickGroups,
        allSticks: this.allSticks,
      };
      try {
        await axios.post("http://localhost:3000/api/data", data);
        alert("Daten erfolgreich gespeichert!");
      } catch (error) {
        console.error("Fehler beim Speichern der Daten:", error);
      }
    },
    async addStick() {
      if (
        !this.newStick.type ||
        !this.newStick.condition ||
        !this.newStick.storageCapacity ||
        !this.newStick.serialNumber ||
        !this.newStick.inventoryNumber ||
        !this.newStick.manufacturerModel
      ) {
        alert("Bitte füllen Sie alle Felder aus, um einen Stick hinzuzufügen.");
        return;
      }

      this.allSticks.push({
        inventoryNumber: this.newStick.inventoryNumber,
        type: this.newStick.type,
        condition: this.newStick.condition,
        storageCapacity: this.newStick.storageCapacity,
        manufacturer: this.newStick.manufacturerModel.split(" ")[0],
        model: this.newStick.manufacturerModel.split(" ")[1],
        serialNumber: this.newStick.serialNumber,
        availability: "Verfügbar",
      });

      this.newStick = {
        type: "",
        condition: "",
        storageCapacity: "",
        serialNumber: "",
        inventoryNumber: "",
        manufacturerModel: "",
      };

      await this.saveData();
      alert("Stick erfolgreich hinzugefügt!");
    },
    async addGroup() {
      if (!this.newGroup) {
        alert("Bitte geben Sie einen Gruppennamen ein.");
        return;
      }

      this.stickGroups.push({
        groupId: this.newGroup,
        stickType: "",
        numberOfSticks: 0,
        sticks: [],
      });

      this.newGroup = "";
      await this.saveData();
      alert("Gruppe erfolgreich erstellt!");
    },
    async deleteGroup(groupId) {
      const groupIndex = this.stickGroups.findIndex(
        (group) => group.groupId === groupId
      );
      if (groupIndex !== -1) {
        this.stickGroups.splice(groupIndex, 1);
        await this.saveData();
        alert("Gruppe erfolgreich gelöscht!");
      }
    },
    async deleteStick(inventoryNumber) {
      for (const group of this.stickGroups) {
        const stickIndex = group.sticks.findIndex(
          (stick) => stick.inventoryNumber === inventoryNumber
        );
        if (stickIndex !== -1) {
          group.sticks.splice(stickIndex, 1);
          group.numberOfSticks--;
        }
      }

      const stickIndex = this.allSticks.findIndex(
        (stick) => stick.inventoryNumber === inventoryNumber
      );
      if (stickIndex !== -1) {
        this.allSticks.splice(stickIndex, 1);
      }

      await this.saveData();
      alert("Stick erfolgreich gelöscht!");
      this.closeEditStickPopup();
    },
    openEditGroupPopup(group) {
      this.selectedGroup = group;
      this.isEditGroupPopupOpen = true;
    },
    closeEditGroupPopup() {
      this.isEditGroupPopupOpen = false;
      this.selectedGroup = null;
    },
    async removeStickFromGroup(inventoryNumber) {
      const stickIndex = this.selectedGroup.sticks.findIndex(
        (stick) => stick.inventoryNumber === inventoryNumber
      );
      if (stickIndex !== -1) {
        this.selectedGroup.sticks.splice(stickIndex, 1);
        this.selectedGroup.numberOfSticks--;
        await this.saveData();
      }
    },
    async addStickToGroup() {
      if (!this.newStickToAdd) {
        alert("Bitte wählen Sie einen Stick aus.");
        return;
      }

      const stickToAdd = this.allSticks.find(
        (stick) => stick.inventoryNumber === this.newStickToAdd
      );

      if (stickToAdd) {
        // Überprüfen, ob der Stick den gleichen Typ wie die Gruppe hat
        if (stickToAdd.type === this.selectedGroup.stickType) {
          this.selectedGroup.sticks.push(stickToAdd);
          this.selectedGroup.numberOfSticks++;
          this.newStickToAdd = "";
          await this.saveData();
        } else {
          alert("Der ausgewählte Stick hat nicht den gleichen Typ wie die Gruppe.");
        }
      }
    },
    openEditStickPopup(stick) {
      this.selectedStick = { ...stick, manufacturerModel: `${stick.manufacturer} ${stick.model}` };
      this.isEditStickPopupOpen = true;
    },
    closeEditStickPopup() {
      this.isEditStickPopupOpen = false;
      this.selectedStick = null;
    },
    async updateStick() {
      const [manufacturer, model] = this.selectedStick.manufacturerModel.split(" ");
      this.selectedStick.manufacturer = manufacturer;
      this.selectedStick.model = model;

      // Überprüfen, ob der Typ des Sticks geändert wurde
      const originalStick = this.allSticks.find(
        (stick) => stick.inventoryNumber === this.selectedStick.inventoryNumber
      );

      if (originalStick && originalStick.type !== this.selectedStick.type) {
        // Wenn der Typ geändert wurde, entferne den Stick aus allen Gruppen
        for (const group of this.stickGroups) {
          const stickIndex = group.sticks.findIndex(
            (stick) => stick.inventoryNumber === this.selectedStick.inventoryNumber
          );
          if (stickIndex !== -1) {
            group.sticks.splice(stickIndex, 1);
            group.numberOfSticks--;
          }
        }
      }

      // Aktualisiere den Stick in der allSticks-Liste
      const stickIndex = this.allSticks.findIndex(
        (stick) => stick.inventoryNumber === this.selectedStick.inventoryNumber
      );
      if (stickIndex !== -1) {
        this.allSticks[stickIndex] = this.selectedStick;
      }

      await this.saveData();
      this.closeEditStickPopup();
      alert("Stick erfolgreich aktualisiert!");
    },
  },
  async mounted() {
    await this.loadData();
  },
};
</script>

<style src="@/assets/styles.css"></style>

<style scoped>
.popup-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000;
}

.popup-content {
  background-color: white;
  padding: 20px;
  border-radius: 8px;
  width: 400px;
  position: relative;
}

.close-popup {
  position: absolute;
  top: 10px;
  right: 10px;
  cursor: pointer;
  font-size: 20px;
}

.popup-content ul {
  list-style-type: none;
  padding: 0;
}

.popup-content ul li {
  margin-bottom: 10px;
}
</style>
<template>
  <div class="container">
    <h1 class="page-title">Reservierung</h1>
    <form @submit.prevent="submitReservation" class="reservation-form">
      <!-- Dropdown für USB-Stick Typ -->
      <div class="form-group">
        <label for="stickType">USB-Stick Typ</label>
        <select id="stickType" v-model="selectedStickType" class="form-control" required>
          <option value="" disabled>Bitte wählen...</option>
          <option v-for="type in stickTypes" :key="type" :value="type">{{ type }}</option>
        </select>
      </div>

      <!-- Dropdown für Gruppen -->
      <div class="form-group" v-if="selectedStickType">
        <label for="group">Gruppe</label>
        <select id="group" v-model="selectedGroup" class="form-control" required>
          <option value="" disabled>Bitte wählen...</option>
          <option v-for="group in getGroupsForType(selectedStickType)" :key="group" :value="group">{{ group }}</option>
        </select>
      </div>

      <div class="form-group">
        <label for="startDate">Startdatum</label>
        <input type="date" id="startDate" v-model="startDate" class="form-control" required />
      </div>

      <div class="form-group">
        <label for="endDate">Rückgabedatum</label>
        <input type="date" id="endDate" v-model="endDate" class="form-control" required />
      </div>

      <button type="submit" class="button">Reservieren</button>
    </form>

    <div v-if="reservationComplete" class="confirmation">
      <h2>Reservierung abgeschlossen</h2>
      <router-link to="/Dashboard">
        <img src="@/assets/checkmark.png" alt="Bestätigung" class="confirmation-icon" />
      </router-link>
    </div>
  </div>
</template>

<script>
import axios from "axios";

export default {
  name: "ReservierungPage",
  data() {
    return {
      stickGroups: [], // Hier werden die Gruppen geladen
      stickTypes: [],  // Hier werden die USB-Stick-Typen gespeichert
      selectedStickType: "",
      selectedGroup: "",
      startDate: "",
      endDate: "",
      reservationComplete: false,
    };
  },
  created() {
    this.loadData(); // Daten vom Server laden
  },
  methods: {
    // Daten vom Server laden
    async loadData() {
      try {
        const response = await axios.get("http://localhost:3000/api/data");
        const data = response.data;
        this.stickGroups = data.stickGroups; // Gruppen laden
        this.stickTypes = Array.from(new Set(data.stickGroups.map(group => group.stickType))); // USB-Stick-Typen extrahieren
      } catch (error) {
        console.error("Fehler beim Laden der Daten:", error);
        alert("Fehler beim Laden der Daten. Bitte überprüfen Sie die Konsole.");
      }
    },
    // Gruppen für den ausgewählten USB-Stick-Typ filtern
    getGroupsForType(type) {
      return this.stickGroups
        .filter(group => group.stickType === type)
        .map(group => group.groupId);
    },
    // Reservierung abschicken
    async submitReservation() {
      const today = new Date();
      today.setHours(0, 0, 0, 0); // Entfernt die Uhrzeit
      const start = new Date(this.startDate);
      const end = new Date(this.endDate);

      if (!this.startDate || !this.endDate || !this.selectedStickType || !this.selectedGroup) {
        alert("Bitte füllen Sie alle Felder aus.");
        return;
      }
      if (start < today) {
        alert("Das Startdatum muss mindestens das heutige Datum oder später sein.");
        return;
      }
      if (start > end) {
        alert("Das Startdatum darf nicht nach dem Enddatum liegen.");
        return;
      }

      try {
        // Markiere die Gruppe als reserviert
        const response = await axios.post("http://localhost:3000/api/reservieren", {
          groupId: this.selectedGroup,
          startDate: this.startDate,
          endDate: this.endDate,
        });

        if (response.status === 200) {
          this.reservationComplete = true;
          alert("Reservierung erfolgreich abgeschlossen!");
        }
      } catch (error) {
        console.error("Fehler beim Reservieren:", error);
        alert("Fehler beim Reservieren. Bitte überprüfen Sie die Konsole.");
      }
    },
  },
};
</script>

<style src="@/assets/styles.css"></style>
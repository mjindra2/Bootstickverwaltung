<template>
  <div class="container">
    <h1 class="page-title">Rückgabe</h1>
    <form @submit.prevent="submitReturn" class="form">
      <!-- Dropdown für USB-Stick Typ -->
      <div class="form-group">
        <label for="stickType">USB-Stick Typ</label>
        <select id="stickType" v-model="selectedStickType" class="form-control" required>
          <option value="" disabled>Bitte wählen...</option>
          <option v-for="type in stickTypes" :key="type" :value="type">{{ type }}</option>
        </select>
      </div>

      <!-- Dropdown für Gruppen -->
      <div class="form-group" v-if="selectedStickType">
        <label for="group">Gruppe</label>
        <select id="group" v-model="selectedGroup" class="form-control" required>
          <option value="" disabled>Bitte wählen...</option>
          <option v-for="group in getReservedGroupsForType(selectedStickType)" :key="group.groupId" :value="group.groupId">{{ group.groupId }}</option>
        </select>
      </div>

      <!-- Dropdown für Zustand -->
      <div class="form-group">
        <label for="zustand">Zustand</label>
        <select id="zustand" v-model="selectedCondition" class="form-control" required>
          <option value="" disabled>Bitte wählen...</option>
          <option v-for="condition in conditions" :key="condition" :value="condition">{{ condition }}</option>
        </select>
      </div>

      <!-- Textarea für Notizen -->
      <div class="form-group" v-if="selectedCondition === 'Defekt'">
        <label for="note">Bemerkung</label>
        <textarea
          id="note"
          v-model="note"
          class="form-control"
          placeholder="Bitte geben Sie eine Bemerkung ein..."
          required
        ></textarea>
      </div>

      <!-- Checkbox-Liste -->
      <div class="form-group" v-if="selectedCondition === 'Defekt' && selectedGroup">
        <label>Defekte/r Bootstick/s</label>
        <form action="#">
          <ul class="checkbox-list">
            <li v-for="stick in getSticksForGroup(selectedGroup)" :key="stick.inventoryNumber">
              <label>
                <input
                  type="checkbox"
                  :value="stick.inventoryNumber"
                  v-model="selectedDefectiveSticks"
                  class="checkbox-input"
                />
                <span>{{ stick.inventoryNumber }} - {{ stick.type }}</span>
              </label>
            </li>
          </ul>
        </form>
      </div>

      <button type="submit" class="button">Zurückgeben</button>
    </form>

    <!-- Bestätigung -->
    <div v-if="returnComplete" class="confirmation">
      <h2>Rückgabe abgeschlossen</h2>
      <router-link to="/Dashboard">
        <img src="@/assets/checkmark.png" alt="Bestätigung" class="confirmation-icon" />
      </router-link>
    </div>
  </div>
</template>

<script>
import jsonData from "@/data/Test.json";

export default {
  name: "RückgabePage",
  data() {
    return {
      stickTypes: Array.from(new Set(jsonData.stickGroups.map((group) => group.stickType))),
      conditions: ["Neu", "Gebraucht", "Defekt"],
      selectedStickType: "",
      selectedGroup: "",
      selectedCondition: "",
      note: "",
      selectedDefectiveSticks: [],
      returnComplete: false,
    };
  },
  methods: {
    getReservedGroupsForType(type) {
      return jsonData.stickGroups
        .filter((group) => group.stickType === type && group.availability === "Reserviert")
        .map((group) => ({
          groupId: group.groupId,
          sticks: group.sticks
        }));
    },
    getSticksForGroup(groupId) {
      const group = jsonData.stickGroups.find((group) => group.groupId === groupId);
      return group ? group.sticks : [];
    },
    submitReturn() {
      if (!this.selectedStickType || !this.selectedGroup || !this.selectedCondition) {
        alert("Bitte füllen Sie alle Pflichtfelder aus.");
        return;
      }
      if (this.selectedCondition === "Defekt") {
        if (!this.note.trim()) {
          alert("Bitte geben Sie eine Bemerkung ein.");
          return;
        }
        if (this.selectedDefectiveSticks.length === 0) {
          alert("Bitte wählen Sie mindestens einen defekten Bootstick aus.");
          return;
        }
      }

      // Markiere die Gruppe als verfügbar
      const group = jsonData.stickGroups.find((group) => group.groupId === this.selectedGroup);
      if (group) {
        group.availability = "Verfügbar";
        group.reservedBy = null;
      }

      this.returnComplete = true;
    },
  },
};
</script>

<style src="@/assets/styles.css"></style>